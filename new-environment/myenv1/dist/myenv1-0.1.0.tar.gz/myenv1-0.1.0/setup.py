# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['myenv1']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.23.3,<2.0.0', 'pandas>=1.5.0,<2.0.0', 'pyodbc>=4.0.34,<5.0.0']

setup_kwargs = {
    'name': 'myenv1',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'AbdulRehmanThebo',
    'author_email': 'arehman.thebo@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
